/**
 * Created by jonrobins on 07/08/2014.
 */
var configuration = angular.module('clientApp');

configuration.constant('API_URL', 'http://10.8.12.44:8080');
