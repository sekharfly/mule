'use strict';

/**
 * @ngdoc function
 * @name clientApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the clientApp
 */
angular.module('clientApp')
  .controller('MainCtrl', function ($scope, $rootScope, message, PubNub) {

        $scope.messages = [];
        $scope.channel = 'my_channel';

        PubNub.init({
            subscribe_key: 'sub-c-93ac4a0a-f45a-11e8-86f0-9a6b1c0db2e9'
        });

        PubNub.ngSubscribe({ channel: $scope.channel });

        $rootScope.$on(PubNub.ngMsgEv($scope.channel), function(ngEvent, payload) {
            $scope.$apply(function() {
                $scope.messages.push(payload.message);
            });
        });

        $scope.save = function(m){
            message.save(m);
        }
  });
