pubnub-chat
===========

PubNub chat application using a Java Spring boot REST API and a angularjs client
